package poo2.login.model;

public class ClassA {

	private int valor;
	
	public void setValor(int valor) {
		this.valor = valor;
	}
	
	public int getValor(){
		return valor;
	}
	
}
